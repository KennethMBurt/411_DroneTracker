import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.concurrent.CountDownLatch;
import javax.swing.*;


public class Delivery extends SwingWorker<Void, String>{
    private static Connection connection;
    private static PreparedStatement getPackage;
    private static PreparedStatement setLocation;
    private static PreparedStatement getDrone;
    private static PreparedStatement getAddress;
    private static PreparedStatement getTime;
    private static PreparedStatement updateTime;
    private static PreparedStatement updateDrone;
    private static PreparedStatement RemovePackage;
    private static ResultSet resultSet;
    private Timer timer;
    private long delay;
    
    public void start(long delay) {
        this.delay = delay;
        execute(); // Start the background task
    }

    
    @Override
    protected Void doInBackground() throws Exception {
        String drone = "000001";
        try {
            while(true){
            Thread.sleep(delay);
            connection = DBConnection.getConnection();
            String Output = claimPackage();
            if (Output != "000000"){
                do{
                drone = claimDrone(Output);
                if (drone != "000001"){
                    keepTime(Output, drone);
                    System.out.println("Out");
                    update(drone);
                    keepTime(Output, drone);
                    System.out.println("Out2");
                    returnDrone(drone,Output);
                }
                }while(drone == "000001");
            } } 
        } catch (InterruptedException ex) {
            Logger.getLogger(Delivery.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    
    
    
    private String claimPackage(){ //works
        String id = "000000";
        connection = DBConnection.getConnection();
        try
        {
         getPackage = connection.prepareStatement("select packageid from app.package where location=?"); 
         getPackage.setString(1,"warehouse");
         resultSet = getPackage.executeQuery();
         if (resultSet.next()) {
            id = resultSet.getString(1);
            setLocation = connection.prepareStatement("UPDATE app.package SET location = ? WHERE packageid = ?");
            setLocation.setString(1,"out");
            setLocation.setString(2, id);
            setLocation.executeUpdate();
        }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return id;
    }
    
    
   private String claimDrone(String packageID){
        String id = "000001";
        connection = DBConnection.getConnection();
        try
        {
         getDrone = connection.prepareStatement("select droneid from app.drone where status=?"); 
         getDrone.setString(1,"waiting");
         resultSet = getDrone.executeQuery();
         if (resultSet.next()) {
            id = resultSet.getString(1);
            setLocation = connection.prepareStatement("UPDATE app.drone SET status = ?, package = ? WHERE droneid = ?");
            setLocation.setString(1,"out");
            setLocation.setString(2,packageID);
            setLocation.setString(3, id);
            setLocation.executeUpdate();
        }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return id;
    }
   
   public void keepTime(String id, String droneID) throws InterruptedException {
        int time = getTime(id);
        final int[] timeArray = {time / 100, time % 100}; // Using an array to hold minutes and seconds
        CountDownLatch latch = new CountDownLatch(1);

        timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int minutes = timeArray[0];
                int seconds = timeArray[1];

                if (minutes > 0 || seconds > 0) {
                    if (seconds == 0) {
                        seconds = 59;
                        minutes--;
                    } else {
                        seconds--;
                    }
                    // Update any UI elements or perform actions with the updated minutes and seconds here
                    System.out.printf("%02d:%02d%n", minutes, seconds);
                    // Update the array with the new values
                    timeArray[0] = minutes;
                    timeArray[1] = seconds;
                    updateTime(droneID, timeArray[0], timeArray[1]);
                } else {
                    // Stop the timer when it reaches 0
                    timer.stop();
                    latch.countDown(); // Signal that the timer has ended
                }
            }
        });

        // Start the timer
        timer.start();

        // Wait until the timer ends
        latch.await();
    }
   private int getTime(String id){
       int time = 0;
        connection = DBConnection.getConnection();
        try
        {
         getAddress = connection.prepareStatement("select address from app.package where packageid=?"); 
         getAddress.setString(1,id);
         resultSet = getAddress.executeQuery();
         if (resultSet.next()) {
            String address = resultSet.getString(1);
            getTime = connection.prepareStatement("select time from app.address where address=?"); 
            getTime.setString(1,address);
            resultSet = getTime.executeQuery();
            if (resultSet.next()) {
                time = resultSet.getInt(1);
            }
        }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return time;
   }
   
   private void updateTime(String id, int min, int sec){
       int hold = (min * 100) + sec;
       String time = String.valueOf(hold);
       connection = DBConnection.getConnection();
        try {
            updateTime = connection.prepareStatement("UPDATE app.drone SET location = ? WHERE droneid = ?");
            updateTime.setString(1, time);
            updateTime.setString(2, id);
            updateTime.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Delivery.class.getName()).log(Level.SEVERE, null, ex);
        }
   }
   
   private void update(String droneid){
       connection = DBConnection.getConnection();
       try {
            updateDrone = connection.prepareStatement("UPDATE app.drone SET status = ? WHERE droneid = ?");
            updateDrone.setString(1, "returning");
            updateDrone.setString(2, droneid);
            updateDrone.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(Delivery.class.getName()).log(Level.SEVERE, null, ex);
        }
   }
   
   private void returnDrone(String droneid, String id){
       connection = DBConnection.getConnection();
        try {
            updateDrone = connection.prepareStatement("UPDATE app.drone SET location = ?, status = ?, package = ? WHERE droneid = ?");
            updateDrone.setString(1, "warehouse");
            updateDrone.setString(2, "waiting");
            updateDrone.setString(3, "none");
            updateDrone.setString(4, droneid);
            updateDrone.executeUpdate();
            RemovePackage = connection.prepareStatement("DELETE FROM app.package WHERE packageid = ?");
            RemovePackage.setString(1,id);
            RemovePackage.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Delivery.class.getName()).log(Level.SEVERE, null, ex);
        }
   }
}
