import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
public class DroneQueries {
    private static Connection connection;
    private static PreparedStatement setDrone;
    private static PreparedStatement deleteDrone;
    private static ResultSet resultSet;
    
    public static boolean addDrone(String id){
        connection = DBConnection.getConnection();
        boolean added = true;
        connection = DBConnection.getConnection();
        try
        {
            // checks to see if username and usercode is a duplicate
            if (!isDroneExists(id)) {
            setDrone = connection.prepareStatement("insert into app.drone (droneid, location, status, package) values (?, ?, ?, ?)");
            setDrone.setString(1, id);
            setDrone.setString(2, "warehouse");
            setDrone.setString(3, "waiting");
            setDrone.setString(4, "none");
            setDrone.executeUpdate();}
            else{ //if there is duplicate
                added = false;
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return added;
    }
    
    private static boolean isDroneExists(String id) throws SQLException {
    PreparedStatement checkUser = null;
    ResultSet resultSet = null;
    boolean userExists = false;

    try {
        checkUser = connection.prepareStatement("SELECT COUNT(*) FROM app.drone WHERE droneid = ?");
        checkUser.setString(1, id);
        resultSet = checkUser.executeQuery();

        if (resultSet.next()) {
            int count = resultSet.getInt(1);
            userExists = count > 0;
        }
    } finally {
        // Close resources in the finally block
        if (resultSet != null) resultSet.close();
        if (checkUser != null) checkUser.close();
    }

    return userExists;
}
    
    
    public static boolean removeDrone(String ID){
        connection = DBConnection.getConnection();
        boolean added = true;
        connection = DBConnection.getConnection();
        try
        {
            // checks to see if username and usercode is a duplicate
            if (isDroneExists(ID)) {
            deleteDrone = connection.prepareStatement("DELETE FROM app.drone WHERE droneid = ?");
            deleteDrone.setString(1, ID);
            deleteDrone.executeUpdate();}
            else{ //if there is duplicate
                added = false;
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return added;
    }
}
