import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class FindDrone {
    private static Connection connection;
    private static PreparedStatement setDrone;
    private static PreparedStatement deleteDrone;
    private static ResultSet resultSet;
    public static String[] findDrone(String id){
        String values[] = {"does not exist", "does not exist", "does not exist"};
        connection = DBConnection.getConnection();
        try
        {
            // checks to see if username and usercode is a duplicate
            if (isDroneExists(id)) {
            setDrone = connection.prepareStatement("select location, status, package from app.drone where droneid = ?");
            setDrone.setString(1, id);
            resultSet = setDrone.executeQuery();
                if (resultSet.next()) {
                    values[0] = resultSet.getString(1);
                    values[1] = resultSet.getString(2);
                    values[2] = resultSet.getString(3);
                    }
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return values;
    }
    
    private static boolean isDroneExists(String id) throws SQLException {
    PreparedStatement checkUser = null;
    ResultSet resultSet = null;
    boolean userExists = false;

    try {
        checkUser = connection.prepareStatement("SELECT COUNT(*) FROM app.drone WHERE droneid = ?");
        checkUser.setString(1, id);
        resultSet = checkUser.executeQuery();

        if (resultSet.next()) {
            int count = resultSet.getInt(1);
            userExists = count > 0;
        }
    } finally {
        // Close resources in the finally block
        if (resultSet != null) resultSet.close();
        if (checkUser != null) checkUser.close();
    }

    return userExists;
}
}
