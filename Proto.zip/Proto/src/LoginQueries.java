import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 *
 * @author tjlic
 */
public class LoginQueries {
    private static Connection connection;
    private static PreparedStatement getUser;
    private static PreparedStatement getAdmi;
    private static ResultSet resultSet;
    public static boolean getLogin(String User,String Pass){
        boolean login = false;
        connection = DBConnection.getConnection();
        try
        {
            getUser = connection.prepareStatement("select username, password from app.employee where username=? and password=?");
            getUser.setString(1, User);
            getUser.setString(2, Pass);
            resultSet = getUser.executeQuery();
            if(resultSet.next()){
                login = true;
            }
            else{
                login = false;
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return login;
    }
    
    public static boolean getAdmin(String User){
        boolean isAdmin = false;
        connection = DBConnection.getConnection();
        try
        {
            getAdmi = connection.prepareStatement("select admin from app.employee where username=?");
            getAdmi.setString(1,User);
            resultSet = getAdmi.executeQuery();
            if (resultSet.next()) {
            isAdmin = resultSet.getBoolean("admin");
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return isAdmin;
    }
}
