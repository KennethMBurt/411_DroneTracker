import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author tjlic
 */
public class EmployeeQueries {
    private static Connection connection;
    private static PreparedStatement setUser;
    private static PreparedStatement getUsers;
    private static ResultSet resultSet;
    
    public static boolean addEmployee(String name, String pass, String code, boolean admin){
        boolean added = true;
        connection = DBConnection.getConnection();
        try
        {
            // checks to see if username and usercode is a duplicate
            if (!isUserExists(name, code)) {
            setUser = connection.prepareStatement("insert into app.employee (username, password, usercode, admin) values (?, ?, ?, ?)");
            setUser.setString(1, name);
            setUser.setString(2, pass);
            setUser.setString(3, code);
            setUser.setBoolean(4, admin);
            setUser.executeUpdate();}
            else{ //if there is duplicate
                added = false;
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return added;
    }
    
    
    private static boolean isUserExists(String username, String userCode) throws SQLException {
    PreparedStatement checkUser = null;
    ResultSet resultSet = null;
    boolean userExists = false;

    try {
        checkUser = connection.prepareStatement("SELECT COUNT(*) FROM app.employee WHERE username = ? OR usercode = ?");
        checkUser.setString(1, username);
        checkUser.setString(2, userCode);
        resultSet = checkUser.executeQuery();

        if (resultSet.next()) {
            int count = resultSet.getInt(1);
            userExists = count > 0;
        }
    } finally {
        // Close resources in the finally block
        if (resultSet != null) resultSet.close();
        if (checkUser != null) checkUser.close();
    }

    return userExists;
}
    
    
}
