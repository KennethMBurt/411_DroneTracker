import java.util.Random;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 *
 * @author tjlic
 */
public class MakeAddress {
    private static Connection connection;
    private static PreparedStatement setUser;
    private static PreparedStatement getUsers;
    private static ResultSet resultSet;
    public static void addAdress(String address){
        Random rand = new Random();
        int mins = rand.nextInt(30);
        int secs = rand.nextInt(60);
        mins = mins * 100;
        int time = mins + secs;
        connection = DBConnection.getConnection();
        try
        {
            setUser = connection.prepareStatement("insert into app.address (address, time) values (?, ?)");
            setUser.setString(1, address);
            setUser.setInt(2, time);
            setUser.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
}
