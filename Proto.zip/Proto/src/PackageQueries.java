import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Calendar;
/**
 *
 * @author tjlic
 */
public class PackageQueries {
    private static Connection connection;
    private static PreparedStatement setUser;
    private static PreparedStatement getUsers;
    private static ResultSet resultSet;
    public static void addPackage(String ID, String Address, String Location){
        connection = DBConnection.getConnection();
        try
        {
            // checks to see if username and usercode is a duplicate
            if (isAddressExists(Address)) {
                setUser = connection.prepareStatement("insert into app.package (packageid, address, location, date) values (?, ?, ?, ?)");
                setUser.setString(1, ID);
                setUser.setString(2, Address);
                setUser.setString(3, Location);
                Timestamp timestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
                setUser.setTimestamp(4, timestamp);
                setUser.executeUpdate();}
            else{ //if there is duplicate
               MakeAddress.addAdress(Address);
               setUser = connection.prepareStatement("insert into app.package (packageid, address, location, date) values (?, ?, ?, ?)");
                setUser.setString(1, ID);
                setUser.setString(2, Address);
                setUser.setString(3, Location);
                Timestamp timestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
                setUser.setTimestamp(4, timestamp);
                setUser.executeUpdate();
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
    
    private static boolean isAddressExists(String address) throws SQLException {
    PreparedStatement checkUser = null;
    ResultSet resultSet = null;
    boolean userExists = false;

    try {
        checkUser = connection.prepareStatement("SELECT COUNT(*) FROM app.address WHERE address = ?");
        checkUser.setString(1, address);
        resultSet = checkUser.executeQuery();

        if (resultSet.next()) {
            int count = resultSet.getInt(1);
            userExists = count > 0;
        }
    } finally {
        // Close resources in the finally block
        if (resultSet != null) resultSet.close();
        if (checkUser != null) checkUser.close();
    }

    return userExists;
}
}
